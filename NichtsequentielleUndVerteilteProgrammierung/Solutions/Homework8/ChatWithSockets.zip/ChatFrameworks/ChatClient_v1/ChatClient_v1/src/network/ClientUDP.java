package network;

import fx.ClientGUI;

public class ClientUDP extends AbstractChatClient {

    public ClientUDP(ClientGUI gui) {
        super(gui);
    }

    @Override
    public void sendChatMessage(String msg) {

    }

    @Override
    public void connect(String address, String port) {

    }

    @Override
    public void disconnect() {

    }

    @Override
    public void terminate() {

    }
}

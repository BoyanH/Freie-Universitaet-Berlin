package network;

import fx.ClientGUI;

public class MyClient extends AbstractChatClient{

	public MyClient(ClientGUI gui) {
		super(gui);
	}

	@Override
	public void sendChatMessage(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void connect(String address, String port) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void terminate() {
		// TODO Auto-generated method stub
		
	}

}

package network;

import fx.ServerGUI;

public class MyServer extends AbstractChatServer{

	public MyServer(ServerGUI gui) {
		super(gui);
	}

	@Override
	public void receiveConsoleCommand(String command, String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void start(String port) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void terminate() {
		// TODO Auto-generated method stub
		
	}

}
